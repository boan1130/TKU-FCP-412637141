public class Test_02 {
    public static void main(String[]args){
        double celsius = 25.0;
        double F = (celsius*9/5)+32;
        System.out.println("F="+F); 
    }
}
