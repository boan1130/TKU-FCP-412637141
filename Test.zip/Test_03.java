public class Test_03 {
    public static void main(String[]args){
        int length = 8;
        int width = 5;
       
        int area = length * width;
        int perimeter = 2 * (length + width);

        System.out.printf("Area: %d\n", area);
        System.out.printf("Perimeter: %d\n",perimeter);
    }
}
